CREATE TABLE Category_Management
(Index_seq VARCHAR2(10), 
Category_name VARCHAR2(10), 
Id_seq VARCHAR2(10));

CREATE Admin(Email Varchar2(10) PRIMARY KEY, Password Varchar2(10));

CREATE  SEQUENCE id_seq START WITH 1 INCREMENT BY 1;

CREATE  SEQUENCE index_seq START WITH 1 INCREMENT BY 1;
