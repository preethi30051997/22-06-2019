package com.capgemini.bookstore.test;

import java.sql.Connection;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.bookstore.dao.CategoryDao;
import com.capgemini.bookstore.exception.CategoryException;
import com.capgemini.bookstore.utility.DBConnection;

public class DBConnectionTest {

	static CategoryDao daotest;
	static Connection dbCon;

	@BeforeClass
	public static void initialize() {
		daotest = new CategoryDao();
		dbCon = null;
	}

	@Before
	public void beforeEachTest() {
		System.out.println("----Starting DBConnection Test Case----\n");
	}

	/**
	 * Test case for Establishing Connection
	 * 
	 * @throws CategoryException
	 **/
	@Test
	public void test() throws CategoryException {
		Connection dbCon = DBConnection.getConnection();
		Assert.assertNotNull(dbCon);
	}

	@After
	public void afterEachTest() {
		System.out.println("----End of DBConnection Test Case----\n");
	}

	@AfterClass
	public static void destroy() {
		System.out.println("\t----End of Tests----");
		daotest = null;
		dbCon = null;
	}

}
