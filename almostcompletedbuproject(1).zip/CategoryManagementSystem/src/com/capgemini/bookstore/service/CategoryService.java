package com.capgemini.bookstore.service;

import java.sql.PreparedStatement;
import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.bookstore.bean.CategoryBean;
import com.capgemini.bookstore.dao.CategoryDao;
import com.capgemini.bookstore.dao.LoginDao;
import com.capgemini.bookstore.exception.CategoryException;

public class CategoryService implements ICategoryService {

	PreparedStatement preparedStatement;
	//static int categoryId = 1;
	//static Scanner scanner = new Scanner(System.in);
	CategoryDao categoryDao = new CategoryDao();

	public int addCategoryDetails(CategoryBean categoryBean) throws CategoryException {
		categoryDao = new CategoryDao();
		int getId = categoryDao.addCategoryDetails(categoryBean);
		return getId;
	}

	public List<CategoryBean> retriveAll() throws CategoryException {

		categoryDao = new CategoryDao();
		return categoryDao.retriveAll();

	}

	public int deleteCategoryDetails(String categoryName) throws CategoryException {
		int identification=0;
		categoryDao = new CategoryDao();
		try {
			identification=	categoryDao.deleteCategoryDetails(categoryName);
		} catch (CategoryException e) {

			throw new CategoryException("Tehnical problem occured refer log");
		}
		return identification;

	}

	public int editCategoryDetails(String existingCategory, String newCategory) throws CategoryException {

		categoryDao = new CategoryDao();
		return categoryDao.editCategoryDetails(existingCategory, newCategory);

	}

	public void validateName(String name) throws CategoryException {
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]{1,29}";
		//String nameRegEx="^[a-zA-Z0-9 ]+$";
		if (!Pattern.matches(nameRegEx, name)) {
			throw new CategoryException("First letter should be capital and length must be in between 2 to 30 \n");
		}
	}

	public boolean validate() throws CategoryException {

		LoginDao loginDoa = new LoginDao();
		boolean valid = loginDoa.validate();
		return valid;
	}

	public int isValidName(String existingCategory) throws CategoryException {

		categoryDao = new CategoryDao();
		return categoryDao.isValidName(existingCategory);
	}

}
