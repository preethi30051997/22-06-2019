package com.capgemini.bookstore.dao;

import java.util.List;

import com.capgemini.bookstore.bean.CategoryBean;
import com.capgemini.bookstore.exception.CategoryException;

public interface ICategoryDao {

	public int addCategoryDetails(CategoryBean PBobj) throws CategoryException;

	public List<CategoryBean> retriveAll() throws CategoryException;

	public int deleteCategoryDetails(String id1) throws CategoryException;

	public int editCategoryDetails(String id2, String cname) throws CategoryException;

	public int isValidName(String categoryName) throws CategoryException;
}
